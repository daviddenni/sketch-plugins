//
//  SketchIconsFramework.h
//  SketchIconsFramework
//
//  Created by Antoine on 19/12/2017.
//  Copyright © 2017 Antoine. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for SketchIconsFramework.
FOUNDATION_EXPORT double SketchIconsFrameworkVersionNumber;

//! Project version string for SketchIconsFramework.
FOUNDATION_EXPORT const unsigned char SketchIconsFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SketchIconsFramework/PublicHeader.h>


